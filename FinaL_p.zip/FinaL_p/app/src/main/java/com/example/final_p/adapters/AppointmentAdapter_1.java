package com.example.final_p.adapters;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.final_p.R;
import com.example.final_p.classes.Appointment;

import java.util.List;
public class AppointmentAdapter_1 extends RecyclerView.Adapter<AppointmentAdapter_1.ViewHolder> {
    private List<Appointment> appointmentList;

    public AppointmentAdapter_1(List<Appointment> appointmentList) {
        this.appointmentList = appointmentList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.apt_cardview, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Appointment appointment = appointmentList.get(position);
        holder.aptTime.setText(appointment.getTime());
        holder.orderBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle button click
            }
        });
    }

    @Override
    public int getItemCount() {
        return appointmentList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        EditText aptTime;
        Button orderBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            aptTime = itemView.findViewById(R.id.apt_time);
            orderBtn = itemView.findViewById(R.id.order_btn);
        }
    }
}
