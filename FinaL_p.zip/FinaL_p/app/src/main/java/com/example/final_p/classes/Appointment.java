package com.example.final_p.classes;


import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class Appointment {
    private String time; // Time of the appointment
    private String description; // Description of the appointment
    private boolean isAvailable; // Availability of the appointment
    private int date;
    private boolean isMyAppointment;
    private Client client;

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Appointment(String time, String description, boolean isAvailable, int date) {
        this.time = time;
        this.description = description;
        this.isAvailable = isAvailable;
        this.date = date;
        this.isMyAppointment = false;
    }

    // Getters and setters
    public boolean isMyAppointment() {
        return isMyAppointment;
    }

    public void setMyAppointment(boolean myAppointment) {
        isMyAppointment = myAppointment;
    }
    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    public int getDate() {
        return date;
    }

    public void setDate(int date) {
        this.date = date;
    }

    // Static method to fetch appointments from Firebase database
    public static void getAppointmentsFromFirebase(DatabaseReference databaseReference, ValueEventListener valueEventListener) {
        databaseReference.addListenerForSingleValueEvent(valueEventListener);
    }
}

